
<?php $__env->startSection('title'); ?>
Nous contacter | <?php echo e(\App\Http\Controllers\HomeController::title()->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="top-text header-text">
            <h6>RESTEZ EN CONTACT AVEC NOUS</h6>
            <h2>N'hésitez pas à nous envoyer un message sur les besoins de votre entreprise</h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="contact-page">
    <div class="container">

      <div class="row">
        <div class="col-lg-12">
          <div class="inner-content">
            <div class="row">
              <div class="col-lg-6">
                <div id="map">
                     <iframe src="<?php echo e(\App\Http\Controllers\HomeController::title()->map); ?>" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
              </div>
              <div class="col-lg-6 align-self-center">
                <form id="contact" action="<?php echo e(Route('send')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                  <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e(Session::get('fail')); ?></div>
                  <?php elseif(Session::has('success')): ?>
                    <div class="alert alert-info" role="alert"><?php echo e(Session::get('success')); ?></div>
                  <?php endif; ?>
                  <div class="row">
                    <div class="col-lg-6">
                      <fieldset>
                        <input type="text" name="fname" id="fname" placeholder="Prénom" autocomplete="on" required>
                      </fieldset>
                    </div>
                    <div class="col-lg-6">
                      <fieldset>
                        <input type="text" name="sname" id="sname" placeholder="Nom" autocomplete="on" required>
                      </fieldset>
                    </div>
                    <div class="col-lg-12">
                      <fieldset>
                        <input type="text" name="subject" id="subject" placeholder="Sujet" autocomplete="on" required>
                      </fieldset>
                    </div>
                    <div class="col-lg-12">
                      <fieldset>
                        <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Email" required="">
                      </fieldset>
                    </div>
                    <div class="col-lg-12">
                      <fieldset>
                        <textarea name="message" type="text" class="form-control" id="message" placeholder="Message" required=""></textarea>  
                      </fieldset>
                    </div>
                    <div class="col-lg-12">
                      <fieldset>
                        <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane"></i>Envoyer un message</button>
                      </fieldset>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<script src="vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#contact").addClass('active')
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/user/contact.blade.php ENDPATH**/ ?>