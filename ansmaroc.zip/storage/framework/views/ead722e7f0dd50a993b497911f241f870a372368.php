
<?php $__env->startSection('title'); ?>
Annonce Maroc
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>a</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/layout/home.blade.php ENDPATH**/ ?>