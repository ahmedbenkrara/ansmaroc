
<?php $__env->startSection('title'); ?>
Annonce Maroc
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    .main{
        margin-top:120px;
        margin-bottom:20px;
    }
</style>

<section class="main">

</section>


<script src="vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#login").addClass('active')
    $("header").addClass("background-header");
    $(window).scroll(function() {
        var header = $('header').height();
        $("header").addClass("background-header");
    });
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/user/dashboard.blade.php ENDPATH**/ ?>