
<?php $__env->startSection('title'); ?>
test 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div style="width:100%; height:1000px; background:black;">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/test.blade.php ENDPATH**/ ?>