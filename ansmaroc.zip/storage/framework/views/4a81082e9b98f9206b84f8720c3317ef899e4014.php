
<?php $__env->startSection('title'); ?>
Créer un administrateur | <?php echo e(\App\Http\Controllers\HomeController::title()->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    #wwidth{
        width: 90%;
    }

    #newbk{
        background:url('assets/images/admin.jfif');
        background-size:cover;
        background-repeat:no-repeat;
        background-position: unset;
    }
</style>

<div class="container main">
    <div class="row justify-content-center">
        <div class="col-md-12 col-lg-10" id="wwidth">
            <div class="wrap d-md-flex">
                <div class="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last" id="newbk">

                </div>
                <div class="login-wrap p-4 p-lg-5">
                    <div class="d-flex">
                        <div class="w-100">
                            <h3 class="mb-4 htitle">S'inscrire</h3>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.store')); ?>" class="signin-form">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <?php if(Session::has('status')): ?>
                               <p class="text-info"><?php echo e(Session::get('status')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <p class="text-danger"><?php echo e($message); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group mb-3">
                            <label class="label" for="fname">Prénom</label>
                            <input type="text" name="fname" value="<?php echo e(old('fname')); ?>" class="input" required>
                        </div>
                        <div class="form-group mb-3">
                            <label class="label" for="sname">Nom</label>
                            <input type="text" name="sname" value="<?php echo e(old('sname')); ?>" class="input" required>
                        </div>
                        <div class="form-group mb-3">
                            <label class="label" for="name">Email</label>
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="input" required>
                        </div>
                        <div class="form-group mb-3">
                            <label class="label" for="password">Mot de passe</label>
                            <input type="password" name="password" class="input" required>
                        </div>
                        <div class="form-group mb-5">
                            <label class="label" for="password_confirmation">Confirmez le mot de passe</label>
                            <input type="password" name="password_confirmation" class="input" required>
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="submitbtn">S'inscrire</button>
                        </div>                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#login").addClass('active')
    $("header").addClass("background-header");
    $(window).scroll(function() {
        var header = $('header').height();
        $("header").addClass("background-header");
    });
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/admin/register.blade.php ENDPATH**/ ?>