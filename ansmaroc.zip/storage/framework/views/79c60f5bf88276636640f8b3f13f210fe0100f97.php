<?php $__env->startSection('title'); ?>
Réinitialiser le mot de passe
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    #wwidth{
        width: 60%;
    }
    
    #btn-dark{
        color: #fff;
        background-color: #8d99af;
        border-color: #8d99af;
        border: none;
        outline: none;
        padding: 8px 14px;
        border-radius: 5px;
        font-size: 14px;
    }

    #email{
        border-radius:5px;
    }

</style>
<div class="container main">
    <div class="row justify-content-center">
        <div class="col-md-12 col-lg-10" id="wwidth">
            <div class="wrap d-md-flex">
                <div class="login-wrap p-4 p-lg-5">

                    <form method="POST" action="<?php echo e(route('password.email')); ?>" class="signin-form">
                        <?php echo csrf_field(); ?>
                        <p class="mb-3">
                        Mot de passe oublié ? Aucun problème. Communiquez-nous simplement votre adresse e-mail et nous vous enverrons par e-mail un lien de réinitialisation de mot de passe qui vous permettra d'en choisir un nouveau.
                        </p>
                        <div class="mb-3">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <p class="text-danger"><?php echo e($message); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mb-3">
                            <?php if(session('status') == "We have emailed your password reset link!"): ?>
                               <p class="text-success">Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail !</p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group mb-3">
                            <label class="label" for="name">Email</label>
                            <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" class="input" required>
                        </div>
                        <button type="submit" id="btn-dark">Lien de réinitialisation de mot de passe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="vendor/jquery/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("header").addClass("background-header");
    $(window).scroll(function() {
        var header = $('header').height();
        $("header").addClass("background-header");
    });
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>