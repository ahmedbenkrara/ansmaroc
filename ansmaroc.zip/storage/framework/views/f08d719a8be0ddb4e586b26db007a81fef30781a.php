<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Annonce Maroc</title>
</head>
<body>
    <h1>Sujet : <?php echo e($details['subject']); ?></h1>
    <h2>Prénom : <?php echo e($details['fname']); ?> Nom : <?php echo e($details['sname']); ?></h2>
    <h2>Email :<?php echo e($details['email']); ?></h2>
    <h2>Message :</h2>
    <p><?php echo e($details['message']); ?></p>
</body>
</html><?php /**PATH C:\Users\ahmed\OneDrive\Bureau\ahmed\ahmed_benkrara\TDI206\PROJECTS\laravel8\ansmaroc\resources\views/email/contactmail.blade.php ENDPATH**/ ?>