<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Annonce_images;
use App\Models\User;

class ImagesController extends Controller
{

}
